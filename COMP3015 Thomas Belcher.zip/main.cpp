#include "application.hpp"
int main() {
    Application application = Application(1920, 1080);
}